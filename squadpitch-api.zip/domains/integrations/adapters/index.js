// Adapter registry — central map of integration type → adapter instance.
//
// To add a new integration type:
//   1. Create a new adapter extending BaseAdapter
//   2. Register it here

import { WebhookAdapter } from "./webhook.adapter.js";
import { SlackAdapter } from "./slack.adapter.js";
import { NotionAdapter } from "./notion.adapter.js";
import { SheetsAdapter } from "./sheets.adapter.js";
import { DiscordAdapter } from "./discord.adapter.js";
import { DriveAdapter } from "./drive.adapter.js";
import { DropboxAdapter } from "./dropbox.adapter.js";
import { HubspotAdapter } from "./hubspot.adapter.js";
import { MailchimpAdapter } from "./mailchimp.adapter.js";
import { ConvertkitAdapter } from "./convertkit.adapter.js";
import { WordpressAdapter } from "./wordpress.adapter.js";
import { WebflowAdapter } from "./webflow.adapter.js";

const adapters = new Map();

const webhook = new WebhookAdapter();
const slack = new SlackAdapter();
const notion = new NotionAdapter();
const sheets = new SheetsAdapter();
const discord = new DiscordAdapter();
const drive = new DriveAdapter();
const dropbox = new DropboxAdapter();
const hubspot = new HubspotAdapter();
const mailchimp = new MailchimpAdapter();
const convertkit = new ConvertkitAdapter();
const wordpress = new WordpressAdapter();
const webflow = new WebflowAdapter();

adapters.set(webhook.name, webhook);
adapters.set(slack.name, slack);
adapters.set(notion.name, notion);
adapters.set(sheets.name, sheets);
adapters.set(discord.name, discord);
adapters.set(drive.name, drive);
adapters.set(dropbox.name, dropbox);
adapters.set(hubspot.name, hubspot);
adapters.set(mailchimp.name, mailchimp);
adapters.set(convertkit.name, convertkit);
adapters.set(wordpress.name, wordpress);
adapters.set(webflow.name, webflow);

/**
 * Get all registered adapters.
 * @returns {Map<string, import("./base.adapter.js").BaseAdapter>}
 */
export function getAdapters() {
  return adapters;
}

/**
 * Get a specific adapter by type name.
 * @param {string} type
 * @returns {import("./base.adapter.js").BaseAdapter | undefined}
 */
export function getAdapter(type) {
  return adapters.get(type);
}

/**
 * Register a new adapter at runtime.
 * @param {import("./base.adapter.js").BaseAdapter} adapter
 */
export function registerAdapter(adapter) {
  adapters.set(adapter.name, adapter);
}
